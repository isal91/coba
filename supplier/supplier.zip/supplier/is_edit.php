<?php
if(isset($_REQUEST['supp_id'])){
include('is_config.php');
if(isset($_REQUEST['edit'])){
extract($_REQUEST);
//update the record if the form was submitted
$query=mysql_query("update supplier set nama_supp='$nama_supp', kode_supp='$kode_supp', alamat='$alamat', kota='$kota', pic='$pic',nr_telp='$nr_telp', email='$email' where supp_id='$id'") or die(mysql_error());
if($query){
//this will be displayed when the query was successful
echo "<div>Record was edited.</div>";
}
}
$id=$_REQUEST['supp_id'];
//this query will select the user data which is to be used to fill up the form
$query=mysql_query("select * from supplier where supp_id='$id'") or die(mysql_error());
$num=mysql_num_rows($query);
//just a little validation, if a record was found, the form will be shown
//it means that there's an information to be edited
if($num>0){
$row=mysql_fetch_assoc($query);
extract($row);
?>
<!--we have our html form here where new user information will be entered-->
    <form action='' method='post' border='0'>
        <table>
            <tr>
                <td>Nama Suplier</td>
                <td><input type='text' name='nama_supp' value='<?php echo $nama_supp;  ?>' /></td>
                </tr>
                <td>Kode Suplier</td>
                <td><input type='text' name='kode_supp' value='<?php echo $kode_supp;  ?>' /></td>
                </tr>
                <tr>
                <td>Alamat</td>
                <td><input type='text' name='alamat' value='<?php echo $alamat;  ?>' /></td>
                </tr>
                <tr>
                <td>Kota</td>
                <td><input type='text' name='kota'  value='<?php echo $kota;  ?>' /></td>
                </tr>
                <td>PIC</td>
                <td><input type='text' name='pic'  value='<?php echo $pic;  ?>' /></td>
                </tr>
                <td>No. Telp</td>
                <td><input type='text' name='nr_telp'  value='<?php echo $nr_telp;  ?>' /></td>
                </tr>
                <td>E-mail</td>
                <td><input type='text' name='email'  value='<?php echo $email;  ?>' /></td>
                </tr>
                <!-- so that we could identify what record is to be updated -->
                <input type='hidden' name='id' value='<?php echo $supp_id ?>' />
                <!-- we will set the action to edit -->
                <input type='submit' value='Edit' name="edit" />
                </td>
            </tr>
        </table>
    </form>
<?php
}else{
echo "<div>User with this id is not found.</div>";
}
}
else{
echo "<div> You are not authorized to view this page";
}
echo "<a href='is_list.php'>Back To List</a>";
?>

