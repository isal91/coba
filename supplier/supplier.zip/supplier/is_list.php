<?php
//koneksi database
include 'is_config.php';

//fungsi pagination . Batas Awal untuk menyeting max perhalaman.
$BatasAwal = 10;
if (!empty($_GET['page'])) {
	$hal = $_GET['page'] - 1;
	$MulaiAwal = $BatasAwal * $hal;
} else if (!empty($_GET['page']) and $_GET['page'] == 1) {
	$MulaiAwal = 0;
} else if (empty($_GET['page'])) {
	$MulaiAwal = 0;
}
?>

<form action="is_search.php" method="POST" name="pencarian" id="pencarian">
  <input type="text" name="search" id="search">    
  <input type="submit" name="submit" id="submit" value="CARI">
</form>
<a href="is_insert_supplier.php">tambah supplier<a>
</br>
		<form>
			<table border="1" width="1000">
				<tr>
					<th>No</th>
					<th>Nama Supplier</th>
					<th>Kode Supplier</th>
					<th>Alamat</th>
					<th>Kota</th>
					<th>PIC</th>
					<th>No. Telp</th>
					<th>Email</th>
					<th>Action</th>					
				</tr>
				<?
				$query = mysql_query("SELECT * FROM supplier LIMIT $MulaiAwal , $BatasAwal")or die(mysql_error());
				$no=1;
				while ($row = mysql_fetch_array($query)) {
				?>
				<tr>
					<td><? echo $no;?></td>
					<td><a href="is_edit.php?supp_id=<? echo $row[0]; ?>" ><?echo $row[1];?></a></td>
					<td><?echo $row[2];?></td>
					<td><?echo $row[3];?></td>
					<td><?echo $row[4];?></td>
					<td><?echo $row[5];?></td>
					<td><?echo $row[6];?></td>
					<td><?echo $row[7];?></td>
					<td><a href="is_delete.php?supp_id=<? echo $row[0]; ?>" >hapus</a>
					</td>			
				</tr>
				<? $no++; } ?>
			</table>
		</form>
<?	
//navigasi
$cekQuery = mysql_query("SELECT * FROM supplier");
$jumlahData = mysql_num_rows($cekQuery);
if ($jumlahData > $BatasAwal) {
	echo '<br/><div style="font-size:10pt;">Page : ';
	$a = explode(".", $jumlahData / $BatasAwal);
	$b = $a[0];
	$c = $b + 1;
	for ($i = 1; $i <= $c; $i++) {
		echo '<a style="text-decoration:none;';
		if ($_GET['page'] == $i) {
			echo 'color:red';
		}
		echo '" href="?page=' . $i . '">' . $i . '</a>, ';
	}
	echo '</div><br>' ;
}

?>