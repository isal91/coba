<?php
include("is_config.php");
//menangkap variabel idbuku yang di kirim oleh view.php untuk di hapus
$id=$_GET['supp_id'];

//query untuk menghapus data
$query="delete from supplier where supp_id='$id'";
$exe=mysql_query($query);

//laporan untuk data yang dihapus
//berhasil atau tidak data dihapus
if ($exe){
	echo "<script>location.replace('is_list.php')</script>";
}else{
	echo "<script>alert('Data Gagal Dihapus Bos')
	location.replace('is_list.php')</script>";
}
?>