<?php
// konfigurasi
include 'is_config.php';

// menampilkan data

$nomor=1;

if ((isset($_POST['submit'])) AND ($_POST['search'])<> "") {	
	$search = $_POST['search'];
	
	$sql = mysql_query("SELECT * FROM supplier WHERE ((nama_supp LIKE '%$search%') OR (kode_supp LIKE '%$search%')) ") or die(mysql_error());	
		?>
			<form action="is_search.php" method="POST" name="pencarian" id="pencarian">
				<input type="text" name="search" id="search">    
				<input type="submit" name="submit" id="submit" value="CARI">
			</form>
			<form>
			<table border="1" width="1000">
				<tr>
					<th>No</th>
					<th>Nama Supplier</th>
					<th>Kode Supplier</th>
					<th>Alamat</th>
					<th>Kota</th>
					<th>PIC</th>
					<th>No. Telp</th>
					<th>Email</th>
					<th>Action</th>					
				</tr>
				<?
					$jumlah = mysql_num_rows($sql);
					if ($jumlah > 0) {
					echo '<p>Ditemukan '.$jumlah.' data.</p>';
					while ($row=mysql_fetch_array($sql)) {				
					extract($row);			
				?>
				<tr>
					<td><? echo $nomor;?></td>
					<td><a href="is_edit.php?supp_id=<? echo $row[0]; ?>" ><?echo $row[1];?></a></td>
					<td><?echo $row[2];?></td>
					<td><?echo $row[3];?></td>
					<td><?echo $row[4];?></td>
					<td><?echo $row[5];?></td>
					<td><?echo $row[6];?></td>
					<td><?echo $row[7];?></td>
					<td><a href="is_delete.php?supp_id=<? echo $row[0]; ?>" >hapus</a>
					</td>			
				</tr>
				<? $nomor++; } ?>
			</table>
		</form>
			<?
		}
	
	else {
   // menampilkan pesan zero data
		echo 'Maaf, hasil pencarian tidak ditemukan.';
	}
}

else { echo 'Masukkan dulu kata kuncinya';}
?>

<?echo "<a href='is_list.php'>Back To List</a>";?>


