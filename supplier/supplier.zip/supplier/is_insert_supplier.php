<html>
<head>
	<title>Create - PHP CRUD</title>
</head>
<body>
	<?php
	if(isset($_POST['save'])){
//include database configuration
		include 'is_config.php';
		extract($_REQUEST);
//sql insert statement
		$nama_supp = $_POST["nama_supp"];
		$kode_supp = $_POST["kode_supp"];
		if (empty($nama_supp)) {
			echo "<span style='color:red;'>*</span>nama supplier tidak boleh kosong";
			header("location : in_insert_supplier.php");
		
		}elseif (empty($kode_supp)) {
			echo "<span style='color:red;'>*</span>nama supplier tidak boleh kosong";
			header("location : in_insert_supplier.php");
			# code...
		}
		else{
			$query=mysql_query("insert into supplier SET nama_supp='$nama_supp', kode_supp='$kode_supp', alamat='$alamat', kota='$kota', pic='$pic',nr_telp='$nr_telp', email ='$email'") or die(mysql_error());	
		 if($query==true){
			echo "<script>alert('Data Berhasil ditambah')
			location.replace('is_list.php')</script>";
			
		}
			
		}

		
//insert query to the database

		

	}
?>
	<!--we have our html form here where user information will be entered-->
	<form action='' method='post' border='0'>
		<table>
			<tr>
				<td>Nama Supplier<span style='color:red;'>*</span></td>
				<td><input type='text' name='nama_supp' /></td>
			</tr>
			<tr>
				<td>Kode Supplier<span style='color:red;'>*</span></td>
				<td><input type='text' name='kode_supp' /></td>
			</tr>
			<tr>
				<td>Alamat</td>
				<td><input type='text' name='alamat' /></td>
			</tr>
			<tr>
				<td>Kota</td>
				<td><input type='text' name='kota' /></td>
			</tr> 
			<tr>
				<td>PIC</td>
				<td><input type='text' name='pic'></td>
			</tr>
			<tr>
				<td>No. Telp</td>
				<td><input type='text' name='nr_telp'></td>
			</tr>
			<tr>
				<td>Email</td>
				<td><input type='text' name='email'></td>
				<tr>
					<td>
						<input type='submit' value='Save' name="save" />
						<input type="reset" value="Reset!">
					</td>
				</tr>
			</table>
		</form>
		<br>
		<?echo "<a href='is_list.php'>Back To List</a>";?>
	</body>
	</html>

