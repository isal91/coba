
<html>
<head>
<title>Supplier</title>
</head>
<body>
<a href="is_list.php">supplier</a>
</body>
</html>

